package com.htn.proj;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    int notifCounter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE); //Get notif manager
                Notification n = new Notification.Builder(getApplicationContext())
                        .setContentTitle(Double.toString(Math.random() * 100))
                        .setContentText("test message")
                        .setSmallIcon(R.drawable.ic_launcher_background) // Temp icon
                        .getNotification();
                n.flags |= Notification.FLAG_AUTO_CANCEL;
                nm.notify(notifCounter++,n);
            }
        });
    }
}
